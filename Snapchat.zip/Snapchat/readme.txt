iOS DeCal SP19 // Proj 2 // Snapchat by Micah Yong

NOTE TO INSTRUCTORS: If an error occurs upon opening the project for the first time, clean the folder, rebuild, and run again.

Snapchat is a multimedia messaging app used globally, created by Evan Spiegel, Bobby Murphy, and Reggie Brown, former students at Stanford University, and developed by Snap Inc., originally Snapchat Inc.

This is a low-grade version of Snapchat designed for educational purposes with functionality and design modeled from the original Snapchat. Enjoy! 
