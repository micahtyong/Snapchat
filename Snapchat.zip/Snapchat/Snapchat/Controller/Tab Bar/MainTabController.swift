//
//  MainTabController.swift
//  Snapchat
//
//  Created by Micah Yong on 3/4/19.
//  All rights reserved.
//

import UIKit

class MainTabController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
