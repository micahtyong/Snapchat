//
//  MyImageCell.swift
//  Snapchat
//
//  Created by Micah Yong on 2/28/19.
//  All rights reserved.
//

import UIKit

class MyImageCell: UICollectionViewCell {
    
    @IBOutlet weak var myImage: UIImageView!
    
}
