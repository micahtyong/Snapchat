//
//  TableViewCell.swift
//  Snapchat
//
//  Created by Micah Yong on 2/28/19.
//  All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var feedLabel: UILabel!

}
