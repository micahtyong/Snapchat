//
//  Data.swift
//  Snapchat
//
//  Created by David [Entei] Xiong on 2/28/19.
//  All rights reserved.
//

import Foundation

class Data {

    let images = ["bear", "bird", "bridge", "cabin", "car", "city", "giraffe", "lion", "man", "moon", "redpanda", "road", "umbrella", "waves"]
    
    let feeds = ["Landscapes", "People", "City Life", "Animals", "CS198-01"]
    
}
